if(localStorage.getItem('products') == null){
    localStorage.setItem('products',JSON.stringify([]));
}
createBody();
function add(){
    event.preventDefault();
   var pid=  document.getElementById("pid").value;
    var name=  document.getElementById("name").value;
    var price = document.getElementById("price").value;
    var imgurl = document.getElementById("imgurl").value;

    var product = {
        pid:pid,
        name:name,
        price:price,
        imgurl:imgurl
    }
   var allProducts =  JSON.parse(localStorage.getItem('products'));
   allProducts.push(product);
   localStorage.setItem('products', JSON.stringify(allProducts));
   clearInputFields();
   createBody();
}

function clearInputFields(){
    document.getElementById("pid").value="";
    document.getElementById("name").value="";
    document.getElementById("price").value="";
    document.getElementById("imgurl").value="";
}

function createBody(){

    var tbody = document.getElementById("tbody");

    var tbodyContent="";

    

  var products =  JSON.parse(localStorage.getItem("products"));

   for(var i=0;i<products.length;i++){
       var product = products[i];

       var image = "<img width='100px' height='50px' src="+product.imgurl+">";

       tbodyContent = tbodyContent + "<tr>" + "<td>" + product.pid+"</td>" + "<td>" + product.name+"</td>"+ "<td>" + product.price+"</td>"+ "<td>" +image+"</td>" +"</tr>"
 
   }
  tbody.innerHTML=tbodyContent;


}